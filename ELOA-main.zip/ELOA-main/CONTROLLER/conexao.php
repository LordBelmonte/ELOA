<?php

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'eloa';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

   // if ($conexao->connect_errno)
    //{
    //    echo "Erro";
    //}
    //else {
   //     echo "Conectado com sucesso";
    //}

?>
